
ZIP CONTENT

1. Dossier_V3_Neuroinflammation_GutBrain.pdf
   Synthèse scientifique structurée sur :
   - NORSE / FIRES
   - inflammation cytokiniques
   - régime cétogène
   - hypothèse axe intestin‑cerveau
   - biomarqueurs et niveaux de preuve

Document destiné à support de discussion scientifique et recherche bibliographique.
