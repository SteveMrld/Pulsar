# PULSAR V14 — BIBLE (UI/UX + Intégration)

## Ce pack contient
- `00_complet.html` — Livrable COMPLET (Landing+App+Démo+Tests embarqués dans un seul HTML)
- `07_code_components.html` — Livrable CODE (galerie composants + tokens + comportements)
- `01_landing.html` — Landing redesign (dark/light)
- `02_app_dashboard.html` — Dashboard (Cockpit + VPS/TDE/PVE)
- `03_demo_ines.html` — Démo Inès autopilotée (13 scènes) + contrôles
- `04_crash_tests.html` — Crash tests (structure UX + compteur 33)
- `05_design_tokens.json` — Tokens (couleurs, typo, spacing, radius)

> Tous les fichiers sont **autonomes** (CSS+JS embarqués). Polices via Google Fonts uniquement.

## Points d’intégration (V13 → V14)
### 1) Scores (Cockpit + vues moteur)
Dans `02_app_dashboard.html` :
- Source : `state.scores.{vps|tde|pve}.score` (0–100)
- Mise à jour UI : `renderScoreCard(...)`

**À brancher** : remplacer `recalc()` (simulation) par votre sortie moteur V13.

### 2) Couches moteur (4 couches)
- Intention / Champs sémantiques : `seedSemanticFields(engine)`
- Contexte / Patterns : `seedPatterns(engine)`
- Règles / garde-fous : `seedRules(engine)`
- Courbe / trajectoire : `seedCurve(engine)`

**À brancher** : alimenter ces fonctions avec les structures V13 (signaux bruts/normalisés, patterns, règles, points de courbe).

### 3) Alertes
Dans `02_app_dashboard.html` :
- bloc `Alertes actives` → structure prête : type (critical/warning/info), source (VPS/TDE/PVE), CTA.

**À brancher** : mapper les alertes V13 vers ces cartes.

### 4) Démo autopilotée
Dans `03_demo_ines.html` :
- `scenes[]` = 13 scènes (titre, narration, scores vps/tde/pve)
- Autopilote par défaut : `playing=true` + timer.

**À brancher** : injecter le contenu narratif V13 + synchroniser les scores réels scène par scène.

### 5) Crash tests
Dans `04_crash_tests.html` :
- `tests[]` est généré en UI (33 items).
- `run()` ne fait qu’animer la progression.

**À brancher** : remplacer `buildTests()` et `run()` par l’exécution réelle des 33 tests V13 (et afficher ✓/✗).

## Règles V14 respectées dans ce pack
- Couleurs **sémantiques invariantes** dark/light (seuls les neutres changent)
- Hiérarchie cockpit lisible immédiatement (3 scores + niveaux + tendance)
- Navigation unifiée (sidebar + header)
- Progressive disclosure (collapsed/expanded sur champs sémantiques)
- Animations fonctionnelles (compteurs, transitions douces, pas de flash)
- Touch targets cohérents (tablet-first)

## Notes
- Ce pack est une **base UI/UX** prête à brancher sur V13 (moteurs non inclus).
- Tout est en **HTML/CSS/JS vanilla**, sans build, sans dépendances lourdes.
